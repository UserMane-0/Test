3d.city v 0.8.0
=======

3d city builder [LAUNCH](http://lo-th.github.io/3d.city/index.html)<br>

The goal is create 3d city builder to test performance for three.js webgl games<br>
With minimum size impact and maximum speed.<br>
3d side use [Three.js](https://github.com/mrdoob/three.js), GLSL 3d model made by me.<br>

This game use simulation source micropolisJS by Graememcc, full convert to ES6<br>
[https://github.com/graememcc/micropolisJS](https://github.com/graememcc/micropolisJS)<br>

Game simulation work in a web worker.

Work in progress

<a target='_blank' href='http://lo-th.github.io/3d.city/index.html'><img src="http://lo-th.github.io/3d.city/assets/img/preview01.jpg"/></a><br>
<a target='_blank' href='http://lo-th.github.io/3d.city/index.html'><img src="http://lo-th.github.io/3d.city/assets/img/preview02.jpg"/></a><br>
<a target='_blank' href='http://lo-th.github.io/3d.city/index.html'><img src="http://lo-th.github.io/3d.city/assets/img/preview03.jpg"/></a><br>

Feature improvements

add different envmap, add snow, destruct ...<br>
correct message display.
